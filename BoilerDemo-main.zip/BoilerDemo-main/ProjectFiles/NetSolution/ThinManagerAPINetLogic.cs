#region Using directives
using System;
using UAManagedCore;
using OpcUa = UAManagedCore.OpcUa;
using FTOptix.HMIProject;
using FTOptix.NetLogic;
using FTOptix.Alarm;
using FTOptix.UI;
using FTOptix.WebUI;
using FTOptix.NativeUI;
using FTOptix.Recipe;
using FTOptix.DataLogger;
using FTOptix.EventLogger;
using FTOptix.SQLiteStore;
using FTOptix.Store;
using FTOptix.OPCUAClient;
using FTOptix.OPCUAServer;
using FTOptix.RAEtherNetIP;
using FTOptix.CoreBase;
using FTOptix.CommunicationDriver;
using FTOptix.Core;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Reflection;
using System.Diagnostics;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Text.Json.Nodes;


#endregion

public class ThinManagerAPINetLogic : BaseNetLogic
{
    public override void Start()
    {
        // Insert code to be executed when the user-defined logic is started
    }

    public override void Stop()
    {
        // Insert code to be executed when the user-defined logic is stopped
    }

    public enum TerminalActions
    {
        Calibrate,
        Disable,
        Enable,
        Poweroff,
        Restart,
        Reboot
    }
    
    public class EventPostRequest
    {
        private string _name;
        public string Name => _name;

        private string _value;
        public string Value => _value;

        public EventPostRequest(string eventName, string eventValue)
        {
            _name = eventName;
            _value = eventValue;
        }
    }

    [ExportMethod]
    public async void postTerminalActionEvent()
    {
        var apiEventProperty = Project.Current.GetVariable("Model/ThinManager/apiEventProperty");
        var apiEventPropertyValue = Project.Current.GetVariable("Model/ThinManager/apiEventPropertyValue");

        var eventArgs = new List<EventPostRequest> {};
        eventArgs.Add(new EventPostRequest(apiEventProperty.Value, apiEventPropertyValue.Value));
        await PostAsyncTerminalEvent(eventArgs);
    }

    [ExportMethod]
    public async void postTerminalActionCalibrate()
    {
        await PostAsyncTerminalAction(TerminalActions.Calibrate);
    }

    [ExportMethod]
    public async void postTerminalActionDisable()
    {
        await PostAsyncTerminalAction(TerminalActions.Disable);
    }

    [ExportMethod]
    public async void postTerminalActionEnable()
    {
        await PostAsyncTerminalAction(TerminalActions.Enable);
    }

    [ExportMethod]
    public async void postTerminalActionPoweroff()
    {
        await PostAsyncTerminalAction(TerminalActions.Poweroff);
    }

    [ExportMethod]
    public async void postTerminalActionRestart()
    {
        await PostAsyncTerminalAction(TerminalActions.Restart);
    }

    [ExportMethod]
    public async void postTerminalActionReboot()
    {
        await PostAsyncTerminalAction(TerminalActions.Reboot);
    }

    [ExportMethod]
    public async void getLicensingData()
    {
        await SendAsyncLicensingMode();
        await SendAsyncLicensingStatus();
    }

    [ExportMethod]
    public async void getSystemVersionData()
    {
        await SendAsyncSystemVersions();
    }

    [ExportMethod]
    public async void getSyncStatus()
    {
        await SendAsyncSyncStatus();
    }

    [ExportMethod]
    public async void getTeminalState()
    {
        var comboBoxTerminals = Owner.Get<ComboBox>("ComboBoxTerminals");
        var comboBoxSelectedItem = comboBoxTerminals.SelectedValue;
        if ((int)comboBoxSelectedItem != 0)
        {
            await SendAsyncTerminalState();
        }
        else
        {
            var buttonCalibrate = Owner.Get<Button>("ButtonAPICalibrate");
            var buttonDisable = Owner.Get<Button>("ButtonAPIDisable");
            var buttonEnable = Owner.Get<Button>("ButtonAPIEnable");
            var buttonPoweroff = Owner.Get<Button>("ButtonAPIPoweroff");
            var buttonReboot = Owner.Get<Button>("ButtonAPIReboot");
            var buttonRestart = Owner.Get<Button>("ButtonAPIRestart");

            buttonCalibrate.Enabled = false;
            buttonDisable.Enabled = false;
            buttonEnable.Enabled = false;
            buttonPoweroff.Enabled = false;
            buttonReboot.Enabled = false;
            buttonRestart.Enabled = false;         
            
            var apiTerminalState = Project.Current.GetVariable("Model/ThinManager/apiTerminalState");
            apiTerminalState.Value = "None";
        }
    }

    public virtual async System.Threading.Tasks.Task SendAsyncSystemVersions()
    {
        var client_ = new HttpClient();
        using (var request_ = new System.Net.Http.HttpRequestMessage())
        {
            #region  "Optix tag references"
            var apiIPaddress = Project.Current.GetVariable("Model/ThinManager/apiIPAddress");
            var apiPortNumber = Project.Current.GetVariable("Model/ThinManager/apiPortNumber");
            var apiKey = Project.Current.GetVariable("Model/ThinManager/apiKey");
            var apiEndPoint = "/api/system/versions";

            var apiThinServer = Project.Current.GetVariable("Model/ThinManager/apiThinServer");
            var apiTermCap = Project.Current.GetVariable("Model/ThinManager/apiTermCap");
            var apiBootLoader = Project.Current.GetVariable("Model/ThinManager/apiBootLoader");
            var apiChainLoader = Project.Current.GetVariable("Model/ThinManager/apiChainLoader");
            var apiUEFI32bitBootLoader = Project.Current.GetVariable("Model/ThinManager/apiUEFI32bitBootLoader");
            var apiUEFI64bitBootLoader = Project.Current.GetVariable("Model/ThinManager/apiUEFI64bitBootLoader");
            var apiFirmwarePackage82Version = Project.Current.GetVariable("Model/ThinManager/apiFirmwarePackage82Version");
            var apiFirmwarePackage92Version = Project.Current.GetVariable("Model/ThinManager/apiFirmwarePackage92Version");
            var apiFirmwarePackage93Version = Project.Current.GetVariable("Model/ThinManager/apiFirmwarePackage93Version");
            #endregion

            var content_ = new System.Net.Http.StringContent("");
            content_.Headers.ContentType = System.Net.Http.Headers.MediaTypeWithQualityHeaderValue.Parse("application/json");
            request_.Content = content_;
            request_.Method = new System.Net.Http.HttpMethod("GET");
            request_.Headers.Add("x-api-key", apiKey.Value);
            var url_ = "https://" + apiIPaddress.Value + ":" + apiPortNumber.Value + apiEndPoint;
            request_.RequestUri = new System.Uri(url_, System.UriKind.RelativeOrAbsolute);

            try
            {
                var response_ = await client_.SendAsync(request_);
                using (HttpContent content = response_.Content)
                {
                    var jsonString = await response_.Content.ReadAsStringAsync();
                    JsonNode jsNode = JsonNode.Parse(jsonString);

                    #region "Optix tag assignments"
                    apiThinServer.Value = jsNode["ThinServer"]!.GetValue<string>();
                    apiTermCap.Value = jsNode["TermCap"]!.GetValue<string>();
                    apiBootLoader.Value = jsNode["BootLoader"]!.GetValue<string>();
                    apiChainLoader.Value = jsNode["ChainLoader"]!.GetValue<string>();
                    apiUEFI32bitBootLoader.Value = jsNode["UEFI32bitBootLoader"]!.GetValue<string>();
                    apiUEFI64bitBootLoader.Value = jsNode["UEFI64bitBootLoader"]!.GetValue<string>();
                    JsonArray firmwarePackages = jsNode!["FirmwarePackages"]!.AsArray()!;                                        
                    apiFirmwarePackage82Version.Value = firmwarePackages[1]["PackageVersion"]!.GetValue<string>();
                    apiFirmwarePackage92Version.Value = firmwarePackages[2]["PackageVersion"]!.GetValue<string>();
                    apiFirmwarePackage93Version.Value = firmwarePackages[3]["PackageVersion"]!.GetValue<string>();
                    #endregion
                }
            }
            catch (System.Exception)
            {
                string error = "Failed to execute ThinManager REST-API: " + url_;
                Log.Error(error);
            }
        }
    }
    public virtual async System.Threading.Tasks.Task SendAsyncSyncStatus()
    {
        var client_ = new HttpClient();
        using (var request_ = new System.Net.Http.HttpRequestMessage())
        {
            var apiIPaddress = Project.Current.GetVariable("Model/ThinManager/apiIPAddress");
            var apiPortNumber = Project.Current.GetVariable("Model/ThinManager/apiPortNumber");
            var apiKey = Project.Current.GetVariable("Model/ThinManager/apiKey");
            var apiEndPoint = "/api/system/synchronization/status";

            var apiSyncState = Project.Current.GetVariable("Model/ThinManager/apiSyncState");
            var apiSyncMode = Project.Current.GetVariable("Model/ThinManager/apiSyncMode");
            var apiSyncPeer = Project.Current.GetVariable("Model/ThinManager/apiSyncPeer");

            var content_ = new System.Net.Http.StringContent("");
            content_.Headers.ContentType = System.Net.Http.Headers.MediaTypeWithQualityHeaderValue.Parse("application/json");
            request_.Content = content_;
            request_.Method = new System.Net.Http.HttpMethod("GET");
            request_.Headers.Add("x-api-key", apiKey.Value);
            var url_ = "https://" + apiIPaddress.Value + ":" + apiPortNumber.Value + apiEndPoint;
            request_.RequestUri = new System.Uri(url_, System.UriKind.RelativeOrAbsolute);

            try
            {
                var response_ = await client_.SendAsync(request_);
                using (HttpContent content = response_.Content)
                {
                    var jsonString = await response_.Content.ReadAsStringAsync();
                    JsonNode jsNode = JsonNode.Parse(jsonString);

                    apiSyncState.Value = jsNode["State"]!.GetValue<string>();
                    apiSyncMode.Value = jsNode["Mode"]!.GetValue<string>();
                    apiSyncPeer.Value = jsNode["Peer"]!.GetValue<string>();
                }
            }
            catch (System.Exception)
            {
                string error = "Failed to execute ThinManager REST-API: " + url_;
                Log.Error(error);
            }
        }
    }

    public virtual async System.Threading.Tasks.Task SendAsyncTerminalState()
    {
        var client_ = new HttpClient();
        using (var request_ = new System.Net.Http.HttpRequestMessage())
        {
            var apiIPaddress = Project.Current.GetVariable("Model/ThinManager/apiIPAddress");
            var apiPortNumber = Project.Current.GetVariable("Model/ThinManager/apiPortNumber");
            var apiKey = Project.Current.GetVariable("Model/ThinManager/apiKey");
            var apiTerminalID = Project.Current.GetVariable("Model/ThinManager/apiSelectedTerminalID");
            var apiEndPoint = "/api/terminals/terminal/" + apiTerminalID.Value + "/status";

            var apiTerminalState = Project.Current.GetVariable("Model/ThinManager/apiTerminalState");

            var content_ = new System.Net.Http.StringContent("");
            content_.Headers.ContentType = System.Net.Http.Headers.MediaTypeWithQualityHeaderValue.Parse("application/json");
            request_.Content = content_;
            request_.Method = new System.Net.Http.HttpMethod("GET");
            request_.Headers.Add("x-api-key", apiKey.Value);
            var url_ = "https://" + apiIPaddress.Value + ":" + apiPortNumber.Value + apiEndPoint;
            request_.RequestUri = new System.Uri(url_, System.UriKind.RelativeOrAbsolute);

            try
            {
                var response_ = await client_.SendAsync(request_);
                using (HttpContent content = response_.Content)
                {
                    var jsonString = await response_.Content.ReadAsStringAsync();
                    JsonNode jsNode = JsonNode.Parse(jsonString);

                    apiTerminalState.Value = jsNode["State"]!.GetValue<string>();

                    var buttonCalibrate = Owner.Get<Button>("ButtonAPICalibrate");
                    var buttonDisable = Owner.Get<Button>("ButtonAPIDisable");
                    var buttonEnable = Owner.Get<Button>("ButtonAPIEnable");
                    var buttonPoweroff = Owner.Get<Button>("ButtonAPIPoweroff");
                    var buttonReboot = Owner.Get<Button>("ButtonAPIReboot");
                    var buttonRestart = Owner.Get<Button>("ButtonAPIRestart");

            buttonCalibrate.Enabled = false;

                    if (apiTerminalState.Value == "UP")
                    {
                        buttonCalibrate.Enabled = true;
                        buttonDisable.Enabled = true;
                        buttonEnable.Enabled = true;
                        buttonPoweroff.Enabled = true;
                        buttonReboot.Enabled = true;
                        buttonRestart.Enabled = true;
                    }
                    else
                    {
                        buttonCalibrate.Enabled = false;
                        buttonDisable.Enabled = false;
                        buttonEnable.Enabled = false;
                        buttonPoweroff.Enabled = false;
                        buttonReboot.Enabled = false;
                    }
                }
            }
            catch (System.Exception)
            {
                string error = "Failed to execute ThinManager REST-API: " + url_;
                Log.Error(error);
            }
        }
    }

    public virtual async System.Threading.Tasks.Task PostAsyncTerminalAction(TerminalActions actionType)
    {
        var client_ = new HttpClient();
        using (var request_ = new System.Net.Http.HttpRequestMessage())
        {
            var apiIPaddress = Project.Current.GetVariable("Model/ThinManager/apiIPAddress");
            var apiPortNumber = Project.Current.GetVariable("Model/ThinManager/apiPortNumber");
            var apiKey = Project.Current.GetVariable("Model/ThinManager/apiKey");
            var apiTerminalID = Project.Current.GetVariable("Model/ThinManager/apiSelectedTerminalID");
            var apiEndPoint = "/api/terminals/" + apiTerminalID.Value + "/" + actionType;

            var content_ = new System.Net.Http.StringContent("");
            content_.Headers.ContentType = System.Net.Http.Headers.MediaTypeWithQualityHeaderValue.Parse("application/json");
            request_.Content = content_;
            request_.Method = new System.Net.Http.HttpMethod("POST");
            request_.Headers.Add("x-api-key", apiKey.Value);
            var url_ = "https://" + apiIPaddress.Value + ":" + apiPortNumber.Value + apiEndPoint;
            request_.RequestUri = new System.Uri(url_, System.UriKind.RelativeOrAbsolute);

            try
            {
                var response_ = await client_.SendAsync(request_);
            }
            catch (System.Exception)
            {
                string error = "Failed to execute ThinManager REST-API: " + url_;
                Log.Error(error);
            }
        }
    }

public virtual async System.Threading.Tasks.Task PostAsyncTerminalEvent(System.Collections.Generic.IEnumerable<EventPostRequest> body)
    {
        var client_ = new HttpClient();
        using (var request_ = new System.Net.Http.HttpRequestMessage())
        {
            var json_ = System.Text.Json.JsonSerializer.Serialize(body);
            var apiIPaddress = Project.Current.GetVariable("Model/ThinManager/apiIPAddress");
            var apiPortNumber = Project.Current.GetVariable("Model/ThinManager/apiPortNumber");
            var apiKey = Project.Current.GetVariable("Model/ThinManager/apiKey");
            var apiTerminalID = Project.Current.GetVariable("Model/ThinManager/apiSelectedTerminalID");
            var apiEndPoint = "/api/events/post";

            var content_ = new System.Net.Http.StringContent(json_);
            content_.Headers.ContentType = System.Net.Http.Headers.MediaTypeWithQualityHeaderValue.Parse("application/json");
            request_.Content = content_;
            request_.Method = new System.Net.Http.HttpMethod("POST");
            request_.Headers.Add("x-api-key", apiKey.Value);
            var url_ = "https://" + apiIPaddress.Value + ":" + apiPortNumber.Value + apiEndPoint;
            request_.RequestUri = new System.Uri(url_, System.UriKind.RelativeOrAbsolute);

            try
            {
                var response_ = await client_.SendAsync(request_);
            }
            catch (System.Exception)
            {
                string error = "Failed to execute ThinManager REST-API: " + url_;
                Log.Error(error);
            }
        }
    }
    public virtual async System.Threading.Tasks.Task SendAsyncLicensingMode()
    {
        var client_ = new HttpClient();
        using (var request_ = new System.Net.Http.HttpRequestMessage())
        {
            var apiIPaddress = Project.Current.GetVariable("Model/ThinManager/apiIPAddress");
            var apiPortNumber = Project.Current.GetVariable("Model/ThinManager/apiPortNumber");
            var apiKey = Project.Current.GetVariable("Model/ThinManager/apiKey");
            var apiEndPoint = "/api/system/licensing/mode";

            var apiLicensingMode = Project.Current.GetVariable("Model/ThinManager/apiLicensingMode");

            var content_ = new System.Net.Http.StringContent("");
            content_.Headers.ContentType = System.Net.Http.Headers.MediaTypeWithQualityHeaderValue.Parse("application/json");
            request_.Content = content_;
            request_.Method = new System.Net.Http.HttpMethod("GET");
            request_.Headers.Add("x-api-key", apiKey.Value);
            var url_ = "https://" + apiIPaddress.Value + ":" + apiPortNumber.Value + apiEndPoint;
            request_.RequestUri = new System.Uri(url_, System.UriKind.RelativeOrAbsolute);

            try
            {
                var response_ = await client_.SendAsync(request_);
                using (HttpContent content = response_.Content)
                {
                    var jsonString = await response_.Content.ReadAsStringAsync();
                    JsonNode jsNode = JsonNode.Parse(jsonString);

                    apiLicensingMode.Value = jsNode["Mode"]!.GetValue<string>();
                }
            }
            catch (System.Exception)
            {
                string error = "Failed to execute ThinManager REST-API: " + url_;
                Log.Error(error);
            }
        }
    }
    public virtual async System.Threading.Tasks.Task SendAsyncLicensingStatus()
    {
        var client_ = new HttpClient();
        using (var request_ = new System.Net.Http.HttpRequestMessage())
        {
            var apiIPaddress = Project.Current.GetVariable("Model/ThinManager/apiIPAddress");
            var apiPortNumber = Project.Current.GetVariable("Model/ThinManager/apiPortNumber");
            var apiKey = Project.Current.GetVariable("Model/ThinManager/apiKey");
            var apiEndPoint = "/api/system/licensing/status";

            var apiTerminalConnectionsUsed = Project.Current.GetVariable("Model/ThinManager/apiTerminalConnectionsUsed");
            var apiTerminalConnectionsAvail = Project.Current.GetVariable("Model/ThinManager/apiTerminalConnectionsAvail");
            var apiTermSecureUsed = Project.Current.GetVariable("Model/ThinManager/apiTermSecureUsed");
            var apiTermSecureAvail = Project.Current.GetVariable("Model/ThinManager/apiTermSecureAvail");
            var apiRelevanceUsed = Project.Current.GetVariable("Model/ThinManager/apiRelevanceUsed");
            var apiRelevanceAvail = Project.Current.GetVariable("Model/ThinManager/apiRelevanceAvail");
            var apiWinTMCUsed = Project.Current.GetVariable("Model/ThinManager/apiWinTMCUsed");
            var apiWinTMCAvail = Project.Current.GetVariable("Model/ThinManager/apiWinTMCAvail");
            var apiMultiMonitorUsed = Project.Current.GetVariable("Model/ThinManager/apiMultiMonitorUsed");
            var apiMultiMonitorAvail = Project.Current.GetVariable("Model/ThinManager/apiMultiMonitorAvail");

            var content_ = new System.Net.Http.StringContent("");
            content_.Headers.ContentType = System.Net.Http.Headers.MediaTypeWithQualityHeaderValue.Parse("application/json");
            request_.Content = content_;
            request_.Method = new System.Net.Http.HttpMethod("GET");
            request_.Headers.Add("x-api-key", apiKey.Value);
            var url_ = "https://" + apiIPaddress.Value + ":" + apiPortNumber.Value + apiEndPoint;
            request_.RequestUri = new System.Uri(url_, System.UriKind.RelativeOrAbsolute);

            try
            {
                var response_ = await client_.SendAsync(request_);
                using (HttpContent content = response_.Content)
                {
                    var jsonString = await response_.Content.ReadAsStringAsync();
                    JsonNode jsNode = JsonNode.Parse(jsonString);
                    JsonArray licenses = jsNode!["Licenses"]!.AsArray()!;                                        
                    apiMultiMonitorUsed.Value = licenses[0]["Used"]!.GetValue<int>().ToString();
                    apiMultiMonitorAvail.Value = licenses[0]["Available"]!.GetValue<int>().ToString();
                    apiWinTMCUsed.Value = licenses[1]["Used"]!.GetValue<int>().ToString();
                    apiWinTMCAvail.Value = licenses[1]["Available"]!.GetValue<int>().ToString();
                    apiRelevanceUsed.Value = licenses[2]["Used"]!.GetValue<int>().ToString();
                    apiRelevanceAvail.Value = licenses[2]["Available"]!.GetValue<int>().ToString();
                    apiTermSecureUsed.Value = licenses[3]["Used"]!.GetValue<int>().ToString();
                    apiTermSecureAvail.Value = licenses[3]["Available"]!.GetValue<int>().ToString();
                    apiTerminalConnectionsUsed.Value = licenses[4]["Used"]!.GetValue<int>().ToString();
                    apiTerminalConnectionsAvail.Value = licenses[4]["Available"]!.GetValue<int>().ToString();


                }
            }
            catch (System.Exception)
            {
                string error = "Failed to execute ThinManager REST-API: " + url_;
                Log.Error(error);
            }
        }
    }


}
