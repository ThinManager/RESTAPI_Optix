using System;
using UAManagedCore;

//-------------------------------------------
// WARNING: AUTO-GENERATED CODE, DO NOT EDIT!
//-------------------------------------------

[MapType(NamespaceUri = "BoilerDemo", Guid = "e0ec74b0e0af4cc392a0b4ff1c4f74ff")]
public class PipeTConnector : FTOptix.UI.ScaleLayout
{
}

[MapType(NamespaceUri = "BoilerDemo", Guid = "c2a8bfa27e20fcaf213542e2c58b891b")]
public class ThinManagerAPI : FTOptix.UI.Panel
{
}

[MapType(NamespaceUri = "BoilerDemo", Guid = "d3eef2c71f1165f50ef7fdb13b83ff87")]
public class TankWidget : FTOptix.UI.Panel
{
}

[MapType(NamespaceUri = "BoilerDemo", Guid = "4bb9384bacd6b235b0f0db477d0972cc")]
public class MainWindow : FTOptix.UI.Window
{
}

[MapType(NamespaceUri = "BoilerDemo", Guid = "b25c8edb35df2acb37220b8cb1c56e4d")]
public class AlarmList : FTOptix.UI.Window
{
}

[MapType(NamespaceUri = "BoilerDemo", Guid = "29437e70992a44739164a48076848b08")]
public class BasePage : FTOptix.UI.Rectangle
{
}

[MapType(NamespaceUri = "BoilerDemo", Guid = "316ec35132b94324835d2dd2e1050f21")]
public class ValveSolenoid : FTOptix.UI.ScaleLayout
{
}

[MapType(NamespaceUri = "BoilerDemo", Guid = "a3daadbcc88c5753e88ae7d8f72bb57f")]
public class BoilerWidget : FTOptix.UI.Panel
{
}

[MapType(NamespaceUri = "BoilerDemo", Guid = "4824f9f9d37546088f8b245da41ce72b")]
public class Chevron : FTOptix.UI.ScaleLayout
{
}

[MapType(NamespaceUri = "BoilerDemo", Guid = "ee09ac72b4bc47939f132c2c7c55de68")]
public class Boiler : FTOptix.UI.ScaleLayout
{
}

[MapType(NamespaceUri = "BoilerDemo", Guid = "6ed6fbe544b23c05d85da20aba3442d1")]
public class StatusWidget : FTOptix.UI.Rectangle
{
}

[MapType(NamespaceUri = "BoilerDemo", Guid = "1b0dc70d5d42c09a70acec1c917ca5d0")]
public class DataPage : BasePage
{
}

[MapType(NamespaceUri = "BoilerDemo", Guid = "06897908427b5ef771111aa27f51c426")]
public class MainPage : BasePage
{
}

[MapType(NamespaceUri = "BoilerDemo", Guid = "a6df1077edf001fbadcd01964c0ff666")]
public class RecipesPage : BasePage
{
}

[MapType(NamespaceUri = "BoilerDemo", Guid = "25f6ccda7336d6324a20475d355294a6")]
public class ConflictsPage : BasePage
{
}

[MapType(NamespaceUri = "BoilerDemo", Guid = "6144fc39c87b2d96cd689469a4a6e4d9")]
public class ThinManager : BasePage
{
}

[MapType(NamespaceUri = "BoilerDemo", Guid = "418d3ef316f63851c863a2457b115502")]
public class AlarmsPage : BasePage
{
}

[MapType(NamespaceUri = "BoilerDemo", Guid = "fa006125890127d665bea8449cc271ec")]
public class PipeStraight : FTOptix.UI.ScaleLayout
{
}

[MapType(NamespaceUri = "BoilerDemo", Guid = "9617749f37fb4b93b8641d056d90659b")]
public class Tank : FTOptix.UI.ScaleLayout
{
}

[MapType(NamespaceUri = "BoilerDemo", Guid = "7a5dfc0d106643908d7c66b50e80d8c5")]
public class PipeFlange : FTOptix.UI.ScaleLayout
{
}

[MapType(NamespaceUri = "BoilerDemo", Guid = "76398dfd1ca24d70b848bc3bf0f42b06")]
public class Pipe90Degree : FTOptix.UI.ScaleLayout
{
}

[MapType(NamespaceUri = "BoilerDemo", Guid = "902a2674b8b0483d81998a82be8647d8")]
public class DoubleWave : FTOptix.UI.ScaleLayout
{
}

[MapType(NamespaceUri = "BoilerDemo", Guid = "1b7c52eeda43434dbbfd1cb734fcde88")]
public class Alarm_Medium_Priority : FTOptix.UI.ScaleLayout
{
}

[MapType(NamespaceUri = "BoilerDemo", Guid = "52490a9efa8b43bbacfc2c6ed12361dc")]
public class HotSurfaceSymbol2 : FTOptix.UI.ScaleLayout
{
}

[MapType(NamespaceUri = "BoilerDemo", Guid = "5def5ff7421d4fdc9043e27001c40ea6")]
public class LowTemperatureSymbol : FTOptix.UI.ScaleLayout
{
}
