#region Using directives
using System;
using UAManagedCore;
using OpcUa = UAManagedCore.OpcUa;
using FTOptix.HMIProject;
using FTOptix.NetLogic;
using FTOptix.NativeUI;
using FTOptix.UI;
using FTOptix.WebUI;
using FTOptix.Alarm;
using FTOptix.Recipe;
using FTOptix.DataLogger;
using FTOptix.EventLogger;
using FTOptix.SQLiteStore;
using FTOptix.Store;
using FTOptix.OPCUAClient;
using FTOptix.OPCUAServer;
using FTOptix.RAEtherNetIP;
using FTOptix.CoreBase;
using FTOptix.CommunicationDriver;
using FTOptix.Core;
#endregion

using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Threading.Tasks;
using System.Text.Json;
using System.Text;
using System.Threading;

//Help
public class TMLogixPinPoint : BaseNetLogic
{
    public string projectName = "Oven_and_BoilerDemo_L85_Echo";
    public string controllerTagScopeName = "";

    public override void Start()
    {
        // Insert code to be executed when the user-defined logic is started
    }

    public override void Stop()
    {
        // Insert code to be executed when the user-defined logic is stopped
    }
     [ExportMethod]
    public async void postTerminalActionEvent()
    {
        IUANode alarmVar = InformationModel.Get(InformationModel.Get(((DataGrid)Owner.Get("AlarmGrid/AlarmsDataGrid")).SelectedItem).Get<IUAVariable>("InputNode").Value);
        var path = GetParentName(alarmVar.NodeId, alarmVar.BrowseName);
        
        var splitPath = path.Split('/');
        var scope = findScope(splitPath);
        var tag = "";

        if (scope != "")
        {
            tag = splitPath[splitPath.Length - 1];
        }
        else
        {
            tag = buildTag(splitPath);
        }
        
        Log.Info("Scope: " + scope);
        Log.Info("Tag: " + tag);

        var selectedPinPointMode = Project.Current.GetVariable("Model/ThinManager/selectedPinPointMode");

        var eventArgs = new List<EventPostRequest> {};
        eventArgs.Add(new EventPostRequest("LogixPinPointOptix", "1"));
        eventArgs.Add(new EventPostRequest("EventType", "PinPoint"));
        eventArgs.Add(new EventPostRequest("Type", selectedPinPointMode.Value));
        eventArgs.Add(new EventPostRequest("Tag", $"{tag}"));
        eventArgs.Add(new EventPostRequest("Scope", $"{scope}"));
        eventArgs.Add(new EventPostRequest("Project", @"C:\Lab Files\" + projectName + ".ACD"));

        CancellationTokenSource ct = new CancellationTokenSource();

        await PostAsyncTerminalEvent(eventArgs);
    }
    private string buildTag(string[] splitPath)
    {
        string tag = "";
        bool tagsNodeFound = false;

        foreach (string item in splitPath)
        {
            if (item.Contains("Tags"))
            {            
                tagsNodeFound = true;
                continue;
            }
            if (tagsNodeFound == true)
            {
                tag = tag + item + ".";
            }
        }
        return tag.Substring(0, tag.Length - 1);
    }
    private string findScope(string[] splitPath)
    {
        string scope = "";
        foreach (string item in splitPath)
        {
            if (item.Contains("Controller Tags"))
            {
                scope = controllerTagScopeName;
                break;
            }
            if (item.Contains(':'))
            {
                string[] findProgram = item.Split(':');
                scope = findProgram[findProgram.Length - 1];
                break;
            }
        }
        return scope;
    }

    private string GetParentName(NodeId inputObj, string outPath = "") 
    {
        var myVar = InformationModel.Get(inputObj);
        IUANode myVarOwner = myVar.Owner ?? null;
        if (myVarOwner != null) {
            outPath = GetParentName(myVarOwner.NodeId, myVarOwner.BrowseName + "/" + outPath);
        }
        return outPath;
    }

public virtual async System.Threading.Tasks.Task PostAsyncTerminalEvent(System.Collections.Generic.IEnumerable<EventPostRequest> body)
    {
        var client_ = new HttpClient();
        using (var request_ = new System.Net.Http.HttpRequestMessage())
        {
            var json_ = System.Text.Json.JsonSerializer.Serialize(body);
            var apiIPaddress = Project.Current.GetVariable("Model/ThinManager/apiIPAddress");
            var apiPortNumber = Project.Current.GetVariable("Model/ThinManager/apiPortNumber");
            var apiKey = Project.Current.GetVariable("Model/ThinManager/apiKey");
            var apiTerminalID = Project.Current.GetVariable("Model/ThinManager/apiSelectedTerminalID");
            var apiEndPoint = "/api/events/post";

            var content_ = new System.Net.Http.StringContent(json_);
            content_.Headers.ContentType = System.Net.Http.Headers.MediaTypeWithQualityHeaderValue.Parse("application/json");
            request_.Content = content_;
            request_.Method = new System.Net.Http.HttpMethod("POST");
            request_.Headers.Add("x-api-key", apiKey.Value);
            var url_ = "https://" + apiIPaddress.Value + ":" + apiPortNumber.Value + apiEndPoint;
            request_.RequestUri = new System.Uri(url_, System.UriKind.RelativeOrAbsolute);

            try
            {
                var response_ = await client_.SendAsync(request_);
            }
            catch (System.Exception)
            {
                string error = "Failed to connect to ThinManager REST-API: " + url_;
                Log.Error(error);
            }
        }
    }
}
public class EventPostRequest
{
    private string _name;
    public string Name => _name;

    private string _value;
    public string Value => _value;

    public EventPostRequest(string eventName, string eventValue)
    {
        _name = eventName;
        _value = eventValue;
    }
}
